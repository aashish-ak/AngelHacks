// import Auth from '@aws-amplify/auth';
import Analytics from '@aws-amplify/analytics';
import AWS from 'aws-sdk';
import async from 'async';
import awsconfig from './aws-exports';
import Amplify, { Auth,  Storage } from 'aws-amplify';
import transcribeservice from "aws-sdk/clients/transcribeservice";
// import { exists } from 'fs'; 
// import { exists } from 'fs';

Amplify.configure({
    Auth: {
        identityPoolId: 'XX-XXXX-X_abcd1234', //REQUIRED - Amazon Cognito Identity Pool ID
        region: 'xxxxx', // REQUIRED - Amazon Cognito Region
        // userPoolId: 'XX-XXXX-X_abcd1234', //OPTIONAL - Amazon Cognito User Pool ID
        // userPoolWebClientId: 'XX-XXXX-X_abcd1234', //OPTIONAL - Amazon Cognito Web Client ID
    },
    Storage: {
        AWSS3: {
            bucket: 'xxxx', //REQUIRED -  Amazon S3 bucket
            region: 'xxxx', //OPTIONAL -  Amazon service region
        }
    }
});

AWS.config.update({ 
    "accessKeyId": "xxxxx",
    "secretAccessKey": "xxxxxx", 
    "region": "xxxxx" 
  }
);

const rekognition = new AWS.Rekognition();
// const transcribeservice = new AWS.TranscribeService();
// retrieve temporary AWS credentials and sign requests
Auth.configure(awsconfig);

// send analytics events to Amazon Pinpoint
Analytics.configure(awsconfig);

const imageChange = document.getElementById('fileupload');
const tags = document.getElementById('ball');
let EventsSent = 0;

const startLabelDetection = (fileName) => {
    return ((callback) =>{
      console.log('asd');
      let params = {
        Video: {
          S3Object: {
            Bucket: 'xxxx',
            Name: 'video.mp4'
          },
        },
          NotificationChannel: { 
          RoleArn: "arn:aws:iam::xxxxxxx:role/RekognitionNew",
          SNSTopicArn: "arn:aws:sns:xxxxxxx:xxxxxxx:Video"
       }
    }
        rekognition.startLabelDetection(params, function(err, data) {
            if (err) callback(err); 
            else {      
                let JobId = data.JobId;
                console.log(JobId);
                callback(null, JobId);
            }
        });
    });  
}


const getLabelDetection = ()=>{
    return (( JobId, callback) =>{
        console.log('Ro');
        var params = {
      JobId: JobId /* required */
      // SortBy: NAME | TIMESTAMP
    };
    rekognition.getLabelDetection(params, function(err, data) {
          console.log(data.JobStatus);
        if (err) callback(err); // an error occurred
        
        else{
          if(data.JobStatus == "IN_PROGRESS"){
          console.log("IN_PROGRESS")
          }
            else {  
            if(data.NextToken == null || data.NextToken == undefined){
                callback(null, data); 
                // successful response
            }else{
                params.NextToken = data.NextToken;
                getLabelDetection();
            } 
          }
        }
      });
    });  
}
let actions = [];
let labelResults = []

let frames = [];
var link = "";

function getData() {
  var params = {
    Bucket: 'xxxx',
    Key: 'gal31.json'
  };
  s3.getObject(params, function (err, data) {
    frames = [];
    if (err) {
      console.log(err);
    } else {
      var music = JSON.parse(data.Body.toString()).results.items; //this will log data to console
      for (var i = 0; i <= actions.length - 1; i++) {
        var temp = [];
        for (var j = 0; j < music.length; j++) {
          if (music[j].alternative[0].includes(actions[i]))
            temp.push(music[j].start_time);
        }
        var start = [];
        if (temp.length != 0) {
          start.push(temp[0]);
          var cur = temp[0];
          for (var j = 1; j < temp.length; j++) {
            if (temp[j] - cur > 10000) start.push(temp[j]);
            cur = temp[j];
          }
        }
        frames.push(start);
      }
    }
  });
  showVideos(frames);
}


const s3 = new AWS.S3();
var myBucket = 'xxxx';
const region2 = 'xxxx';
const bucket2 = 'xxxx';
const key2 = 'temp1.mp3';

function temp() {
  transcribeservice.getTranscriptionJob({ TranscriptionJobName: "gal31" }, function (err, data) {
    if (err) {
      console.log(err, err.stack);
      // reject(err);
    }
    else {
      // resolve(data);
      if (data.TranscriptionJob.TranscriptionJobStatus == "IN_PROGRESS")
        setTimeout(function () {
          console.log("10sec");
          temp();
        }, 10000);
      else {
        link = data.TranscriptionJob.Transcript.TranscriptFileUri;
        getData();
      }
    }
  });
}

function getAudio() {
   const params2 = {
    LanguageCode: 'en-US',
    Media: {
      MediaFileUri: `https://s3-${region2}.amazonaws.com/${bucket2}/${key2}`
    },
    MediaFormat: 'mp3',
    TranscriptionJobName: "gal31",
    // MediaSampleRateHertz: 8001,
    OutputBucketName: bucket2
  };
  transcribeservice.startTranscriptionJob(params2, function (err, data) {
    if (err) {
      console.log(err, err.stack);
    } else {
      temp();
   }
  });

}


function showVideos(frames) {
  
  // document.getElementById("form").remove();
  // document.getElementById("remove").remove();
  // document.getElementById("link").remove();
  // const container = document.getElementById("container");
  // container.innerHTML = '<h1 style="text-align: center; color: white">Event Identifier</h1>';
  const container = document.getElementsByClassName("app")[0];
  container.innerHTML = `<nav>
  <div class="nav-wrapper">
    <img src="logo.png" class="brand-logo center" style="margin-top:-10px; height: 130%"/ >
  </div>
  </nav>`;

  console.log(frames.length);  
  for(var i = 0; i < frames.length; i++) {
    const heading = document.createElement("h3");
    heading.innerHTML = actions[i];
    heading.style.marginLeft = "100px";
    heading.style.fontFamily = 'Montserrat';
    container.appendChild(heading);
    for(var j = 0; j < frames[i][0].length; j++) {
      const vid = document.createElement("video");
      const src = document.createElement("source");
      src.type = "video/mp4";
      // Since video always gets updated, the url remains the same
      if (frames[i][1][j])
        src.src = "https://s3.xxxx.amazonaws.com/xxxx/vid2.mp4#t=" + String(frames[i][0][j] / 1000) + "," + String((frames[i][1][j] / 1000)+2);
      else 
        src.src = "https://s3.xxxx.amazonaws.com/xxxx/vid2.mp4";
      vid.appendChild(src);
      vid.setAttribute("width", "500");
      vid.setAttribute("controls", "controls");
      if (!frames[i][1][j])
        vid.currentTime = frames[i][0][j]/1000;
      vid.style.paddingLeft = "40px";
      vid.style.paddingRight = "40px";
      container.appendChild(vid);
    }
  }
}


function getRelevant(labelResults) {
  for (var i = 0; i < actions.length; i++) {
    var temp = [];
    for (var j = 0; j < labelResults[0].length; j++) {
      if (labelResults[0][j].Label.Name.toLowerCase().includes(actions[i]))
        temp.push(labelResults[0][j].Timestamp);
    }
    var start = [];
    var end = [];
    if (temp.length != 0) {
      start.push(temp[0]);
      var cur = temp[0];
      for (var j = 1; j < temp.length; j++) {
        if (temp[j] - cur > 10000){
          start.push(temp[j]);
          end.push(cur);
        }
        cur = temp[j];
      }
    }
    frames.push([start,end]);
  }
  if(frames.length != 0)
    showVideos(frames);
  else 
    getAudio();
}


function getLabels(JobId, NextToken=false) {
  var params;
  if(NextToken){
    params = {
      JobId: JobId, /* required */
      NextToken: NextToken
    };
  }
  else{
    params = {
      JobId: JobId /* required */
    };
  }
  rekognition.getLabelDetection(params, function(err, data) {
    if (err) console.log(err); // an error occurred
    
    else{
      if(data.JobStatus == "IN_PROGRESS"){
        console.log("IN_PROGRESS in");
        setTimeout(function() {
          console.log("waited 10sec");
          getLabels(JobId)
        }, 10000);
      }
      else if(data.NextToken) {
        labelResults.push(data.Labels);
        getLabels(JobId,data.NextToken);
      }
      else {  
        labelResults.push(data.Labels);
        console.log(labelResults);
        getRelevant(labelResults);
      }
    }
  });
}


tags.addEventListener('change', function(evt){
    actions.push(this.value);
});


imageChange.addEventListener('change', async function(evt){
  document.querySelector('.submitbtnm').innerHTML = "Uploading.."
  
  Storage.put('vid2.mp4', evt.target.files[0], {
    contentType: 'video/mp4'
  }).then (result => console.log(result)) // {key: "test.txt"}
      .catch(err => console.log(err));

  let params = {
    Video: {
      S3Object: {
        Bucket: 'xxxx',
        Name: 'vid2.mp4'
      },
    },
    MinConfidence: 70.0,
    NotificationChannel: {
      RoleArn: "arn:aws:iam::xxxxx:role/RekognitionNew",
      SNSTopicArn: "arn:aws:sns:xxxx:xxxxx:Video"
    }
  }
  rekognition.startLabelDetection(params, function(err, data) {
    if(err) console.log(err)
    let JobId = data.JobId;
    console.log(JobId);
    getLabels(JobId);
  });
  return;
});